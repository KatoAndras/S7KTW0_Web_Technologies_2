
const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;

//public mappa elemeinek elerese
app.use(express.static(path.join(__dirname, 'public')));


app.listen(PORT, () => {
  console.log(`Az Okosotthon Áttekintés weblap elérhető: http://localhost:${PORT}`);
});
